Website Link - https://retail-store-pos-app.netlify.app/
# Retail-Store-POS-Application
This Application Allows user to
- Do CRUD operation Like adding, deleting, modifying and updating items in the list
- Add items along with Quantity in the Cart
- Charge Bill
- Keep track of the customers
- Print Bill

<h2>Tech Stack Used</h2>
- React.js
- Node.js
- Express.js
- MongoDB

